/*
 * Class: CMSC201
 * Instructor: Grigoriy Grinberg
 * Description: Make a JUnit  test class to test methods of isPrime, also identify what some coding terms are (?)
 * Due 12/16/24
 * I pledge that U gave completed the programming assignment independently. I have not copied the code from a student or any source.
 * I have not given my code to any student
 * Name: Graeham Galler
 */
package Project6;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PrimeNumberMethodTest {

	@Test
	void isPrimeish() {
		int IsThisWhatIAmSupposedToBeDoing = 1;
		 assertTrue(PrimeNumberMethod.isPrime(IsThisWhatIAmSupposedToBeDoing));
	}
}

/**
 * Describe a Class: A class holds constructors, and functions in it. And is like an expanded function, but with more features. 
 * Describe a Interface: An interface is something that can be implemented in classes, but is not created in one, so multiple classes can use them.
 * Describe Data fields: Variables declared in classes. The public, private, protected, etc variables made in classes.
 * Describe methods: They can be called on to perform the actions in them, so if you make a multiplaying method to multiply two numbers, you can call it 1000 times if you need.
 */

		  
	



	
