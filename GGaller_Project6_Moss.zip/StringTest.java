/*
 * Class: CMSC201
 * Instructor: Grigoriy Grinberg
 * Description: Make a JUnit  test class to test methods of length, charAt, substring, and indexOf
 * Due 12/16/24
 * I pledge that U gave completed the programming assignment independently. I have not copied the code from a student or any source.
 * I have not given my code to any student
 * Name: Graeham Galler
 */
package Project6;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class StringTest {

	@Test
	void lengthish() {
		String argh = "I am confused as to what I am supposed to be doing!";
		int expect = 51;
		
		
		assertEquals(expect, argh.length());
		
	}
	
	@Test
	void characterish() {
		String yarg = "I think I know better what it is I am supposed to be doing!";
		assertEquals('I', yarg.charAt(0));
	}

	
	@Test
	void substringish() {
		String string1 = "I think I understand what I'm doing now!";
		String expect = "think";
		String equal = string1.substring(2, 7);
		
		assertEquals(expect, equal);
	}
	
	@Test
	void indexOfish() {
		String string2 = "I understand what I'm doing now!";
		int location = string2.indexOf('I');
		assertEquals(0, location);
	}
}

